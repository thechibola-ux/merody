import os, sqlite3
from datetime import datetime
from backend.voice import VoiceManager
from skills.time_skill import TimeSkill
from skills.notes_skill import NotesSkill
from skills.weather_skill import WeatherSkill
from skills.learner_skill import LearnerSkill
from skills.emotion_skill import EmotionEngine

DB = os.getenv('MERODY_DB','/data/merody.db')

class MerodyCore:
    def __init__(self):
        os.makedirs('/data', exist_ok=True)
        self.name = 'MERODY'
        self.db = DB
        self._init_db()
        self.voice = VoiceManager()
        self.emotion = EmotionEngine(self.db)
        self.skills = [
            TimeSkill(),
            WeatherSkill(api_key=os.getenv('OPENWEATHER_KEY')),
            NotesSkill(),
            LearnerSkill(db_path=self.db)
        ]

    def _init_db(self):
        con = sqlite3.connect(self.db)
        cur = con.cursor()
        cur.execute('CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY, key TEXT, value TEXT, created_at TEXT)')
        cur.execute('CREATE TABLE IF NOT EXISTS logs (ts TEXT, direction TEXT, text TEXT)')
        con.commit(); con.close()

    def log(self, direction, text):
        con = sqlite3.connect(self.db)
        cur = con.cursor()
        cur.execute('INSERT INTO logs(ts,direction,text) VALUES (?,?,?)', (datetime.utcnow().isoformat(), direction, text))
        con.commit(); con.close()

    def handle_text(self, text):
        self.log('in', text)
        text = (text or '').strip()
        if not text:
            return 'No recibí nada.'
        for s in self.skills:
            try:
                if s.can_handle(text):
                    result = s.handle(text)
                    if isinstance(result, tuple):
                        base, meta = result
                    else:
                        base, meta = result, None
                    if meta and meta.get('success'):
                        self.emotion.update('success', magnitude=0.5)
                    resp = f"{self.name}: {base} {self.emotion.express(mode='brief')}"
                    self.log('out', resp)
                    return resp
            except Exception as e:
                return f'Error en skill {s.__class__.__name__}: {e}'
        fallback = 'Lo siento, no sé hacer eso todavía.'
        self.log('out', fallback)
        return f"{self.name}: {fallback} {self.emotion.express(mode='brief')}"
