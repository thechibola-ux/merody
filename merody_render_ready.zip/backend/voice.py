import socket, tempfile, os
from gtts import gTTS
import pyttsx3
import playsound
import speech_recognition as sr

def hay_internet(timeout=2):
    try:
        socket.create_connection(('8.8.8.8',53), timeout=timeout)
        return True
    except OSError:
        return False

class VoiceManager:
    def __init__(self, lang='es'):
        self.lang = lang
        self.offline_engine = pyttsx3.init()
        self.offline_engine.setProperty('rate', 160)

    def speak(self, text):
        if hay_internet():
            try:
                tts = gTTS(text=text, lang='es')
                tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.mp3')
                tts.save(tmp.name)
                playsound.playsound(tmp.name)
                os.unlink(tmp.name)
                return
            except Exception:
                pass
        self.offline_engine.say(text)
        self.offline_engine.runAndWait()

    def listen(self, timeout=5, phrase_time_limit=7, language='es-ES'):
        r = sr.Recognizer()
        with sr.Microphone() as src:
            r.adjust_for_ambient_noise(src, duration=0.5)
            audio = r.listen(src, timeout=timeout, phrase_time_limit=phrase_time_limit)
        try:
            return r.recognize_google(audio, language=language)
        except Exception:
            return ''
