from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
import os, uvicorn, sys
sys.path.append(os.path.dirname(__file__)+"/..")
from backend.merody_core import MerodyCore

app = FastAPI(title='MERODY')

core = MerodyCore()

@app.post('/api/query')
async def query(request: Request):
    data = await request.json()
    text = data.get('text','')
    resp = core.handle_text(text)
    return JSONResponse({'response': resp})

@app.get('/api/state')
async def state():
    return JSONResponse(core.get_public_state())

@app.get('/')
async def index():
    return FileResponse('../frontend/index.html')
