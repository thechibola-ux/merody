import re, sqlite3, os
DB = os.getenv('MERODY_DB','/data/merody.db')
from datetime import datetime
class NotesSkill:
    def can_handle(self, text):
        return bool(re.search(r'\b(nota|anota|guardar|recuerdo|recordar|toma nota)\b', text, re.I)) or bool(re.search(r'\b(listar notas|mostrar notas|ver notas)\b', text, re.I))
    def handle(self, text):
        con = sqlite3.connect(DB); cur = con.cursor()
        if re.search(r'\b(listar notas|mostrar notas|ver notas)\b', text, re.I):
            cur.execute('SELECT value FROM memories WHERE key=?', ('note',))
            rows = cur.fetchall(); con.close()
            if not rows: return 'No hay notas guardadas.', {'success': False}
            notes = [r[0] for r in rows]; return '\n'.join(notes), {'success': True}
        m = re.search(r'(?:anota(?:r)?|nota|guardar|toma nota)[:\s-]*(.*)', text, re.I)
        if m and m.group(1).strip():
            note = m.group(1).strip(); cur.execute('INSERT INTO memories(key,value,created_at) VALUES (?,?,?)', ('note', note, datetime.utcnow().isoformat())); con.commit(); con.close(); return 'Nota guardada.', {'success': True}
        con.close(); return '¿Qué quieres que anote?', {'success': False}
