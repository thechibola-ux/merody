import re, requests, os
class WeatherSkill:
    def __init__(self, api_key=None):
        self.api_key = api_key or os.getenv('OPENWEATHER_KEY')
    def can_handle(self, text):
        return bool(re.search(r'\b(clima|tiempo|temperatura|weather)\b', text, re.I))
    def handle(self, text):
        if not self.api_key:
            return 'No tengo la API key de OpenWeather configurada.', {'success': False}
        m = re.search(r'clima en ([\w\s,]+)', text, re.I)
        city = m.group(1).strip() if m else 'Lima'
        url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={self.api_key}&units=metric&lang=es'
        try:
            r = requests.get(url, timeout=6); data = r.json()
            if data.get('cod') != 200: return f'No pude obtener el clima para {city}: {data.get("message")}', {'success': False}
            desc = data['weather'][0]['description']; temp = data['main']['temp']
            return f'Clima en {city}: {desc}. {temp}°C', {'success': True}
        except Exception as e:
            return f'Error obteniendo clima: {e}', {'success': False}
