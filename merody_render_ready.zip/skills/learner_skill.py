import re, requests, sqlite3, os
from bs4 import BeautifulSoup
from datetime import datetime
DB = os.getenv('MERODY_DB','/data/merody.db')
class LearnerSkill:
    def can_handle(self, text):
        return bool(re.search(r'\b(aprende|leer|analiza|guardar url|memoriza)\b', text, re.I)) or bool(re.search(r'\b(buscar|buscar en conocimientos)\b', text, re.I))
    def handle(self, text):
        m = re.search(r'(aprende|leer|analiza|guardar url) (https?://\S+)', text, re.I)
        if m:
            url = m.group(2); return self._fetch_and_store(url), {'success': True}
        m2 = re.search(r'(buscar|buscar en conocimientos) (.+)', text, re.I)
        if m2:
            q = m2.group(2).strip(); return self._search(q), {'success': True}
        return 'Comandos: aprende <url> | buscar <palabra>', {'success': False}
    def _fetch_and_store(self, url):
        try:
            r = requests.get(url, timeout=8, headers={'User-Agent':'MERODY/1.0'}); soup = BeautifulSoup(r.text, 'html.parser')
            title = soup.title.string.strip() if soup.title else url; paragraphs = [p.get_text(separator=' ', strip=True) for p in soup.find_all('p')]; content = '\n'.join(paragraphs)[:20000]
            con = sqlite3.connect(DB); cur = con.cursor(); cur.execute('INSERT INTO memories(key,value,created_at) VALUES (?,?,?)', ('fact:'+title, content, datetime.utcnow().isoformat())); con.commit(); con.close(); return f'Leído y guardado: {title}'
        except Exception as e:
            return f'No pude acceder a {url}: {e}'
