import re
from datetime import datetime
class TimeSkill:
    def can_handle(self, text):
        return bool(re.search(r'\b(hora|qué hora|dime la hora|time)\b', text, re.I))
    def handle(self, text):
        now = datetime.now()
        return f'Son las {now.hour:02d}:{now.minute:02d}.', {'success': True}
