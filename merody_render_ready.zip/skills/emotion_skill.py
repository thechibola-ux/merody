import sqlite3, os
from datetime import datetime
DB = os.getenv('MERODY_DB','/data/merody.db')
class EmotionEngine:
    def __init__(self, db_path=None):
        self.valence = 0.2; self.arousal = 0.3
        os.makedirs(os.path.dirname(DB) or '.', exist_ok=True)
        self._init_db()
    def _init_db(self):
        con = sqlite3.connect(DB); cur = con.cursor(); cur.execute('CREATE TABLE IF NOT EXISTS emotions (ts TEXT, valence REAL, arousal REAL, reason TEXT)'); con.commit(); con.close()
    def _persist(self, reason=''):
        con = sqlite3.connect(DB); cur = con.cursor(); cur.execute('INSERT INTO emotions(ts,valence,arousal,reason) VALUES (?,?,?,?)', (datetime.utcnow().isoformat(), float(self.valence), float(self.arousal), reason)); con.commit(); con.close()
    def update(self, event_type, magnitude=0.1):
        if event_type=='praise': self.valence=min(1.0,self.valence+0.12*magnitude)
        elif event_type=='criticism': self.valence=max(-1.0,self.valence-0.15*magnitude)
        elif event_type=='success': self.valence=min(1.0,self.valence+0.08*magnitude)
        elif event_type=='failure': self.valence=max(-1.0,self.valence-0.08*magnitude)
        self._persist(reason=event_type)
    def get_state(self):
        if self.valence>0.4 and self.arousal<0.6: mood='tranquilo y contento'
        elif self.valence>0.2: mood='positivo'
        elif self.valence<-0.3: mood='preocupado'
        else: mood='neutral'
        return {'valence':self.valence,'arousal':self.arousal,'mood':mood}
    def express(self, mode='brief'):
        s=self.get_state()
        if mode=='brief': return f"({s['mood']})"
        if s['mood']=='tranquilo y contento': return 'Me siento tranquilo y listo.'
        if s['mood']=='positivo': return 'Me siento positivo.'
        if s['mood']=='preocupado': return 'Me siento preocupado.'
        return 'Me siento neutral.'
