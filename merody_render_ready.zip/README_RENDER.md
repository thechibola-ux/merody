MERODY - Ready for Render deployment

----------

1) Descripción

Proyecto MERODY listo para desplegar en Render.com. Incluye FastAPI backend, frontend simple y módulos "skills".

2) Preparar repositorio en GitHub

- Crea una cuenta en https://github.com si no la tienes.
- Crea un nuevo repositorio (público o privado).
- Sube todo el contenido de este paquete al repositorio (arrastrar y soltar en la web o usar git).

3) Variables de entorno recomendadas en Render
- MERODY_DB (opcional) -> ruta a la BD (por defecto /data/merody.db)
- OPENWEATHER_KEY (opcional) -> tu API key de OpenWeather
- OPENAI_API_KEY (opcional) -> tu OpenAI key si usas LLM

4) Desplegar en Render
- Crea una cuenta en https://render.com y verifica tu email.
- Conecta tu cuenta de GitHub a Render.
- En Render, crea un nuevo servicio "Web Service" y selecciona tu repo.
- Selecciona "Dockerfile" como método (ya está incluido).
- Configura las variables de entorno en el panel de Render.
- Despliega y espera a que el build termine.

5) Acceder
- Una vez desplegado, Render te dará una URL pública. Abrela y verás la interfaz de MERODY.

6) Seguridad
- No pongas API keys directamente en el código. Usa variables de entorno.
- Cambia MERODY_MODE a 'assist' antes de activar 'auto-full'.

7) Problemas comunes
- Si hay errores en build: consulta los logs en Render. Suele ser por dependencias (pyaudio no es necesario en servidores, es para local).
- Si quieres TTS en servidor, usa servicios online (gTTS) o configura un motor de sonido en el host.

8) Soporte
- Si quieres, te doy los comandos git para subir el repo y pasos detallados de Render.
